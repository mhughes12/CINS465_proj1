from django.contrib import admin
from app1.models import Board

# Register your models here.
admin.site.register(Board)
